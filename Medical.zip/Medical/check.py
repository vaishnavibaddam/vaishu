import os
print("File exists:", os.path.exists("medicine.pkl"))